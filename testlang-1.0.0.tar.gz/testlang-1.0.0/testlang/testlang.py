
"""
A TestLang compiler
"""
import xml.etree.ElementTree as ET
import pickle
import json

def parse_test(code):
    """
    Parse the TestLang code
    """
    root = ET.fromstring(code)

    questions = {}
    for question in root.findall('question'):
        questionName = question.get('name')
        questions[questionName] = {"ok": [], "bad": []}

        for ok in question.findall('ok'):
            questions[questionName]['ok'].append(ok.text)
        for bad in question.findall('bad'):
            questions[questionName]['bad'].append(bad.text)

    return questions

code_template = """
import random
questions = %s
for question in questions.keys():
    answers= questions[question]["ok"] + questions[question]["bad"]
    random.shuffle(answers)
    print("Question: {question}\\n{answers}".format(question=question, answers="\\n".join(answers)))
    user_input = input("Right answer: ")
    if user_input.lower() == questions[question]["ok"][0].lower():
        print("Right!")
    else:
        raise Exception("Wrong!")
print("Well done!")
"""

def compile(code):
    """
    Receives the TestLang code into the code variable and returns the Python3 code.
    """
    return code_template % (json.dumps(parse_test(code), ensure_ascii=False))

def compile_to_file(code, file):
    """
    Same as the “compile” function, but saves everything to a file, which is passed as the second argument. Saves in an unreadable format.
    """
    with open(file, "wb") as f:
        pickle.dump(compile(code), f)

def execute(file):
    """
    Executes compiled unreadable code.
    """
    with open(file, "rb") as f:
        code = pickle.load(f)
    exec(code)
