from setuptools import setup, find_packages

packages = find_packages()

with open("README.md") as f:
    readme = f.read()

setup(name="testlang", version="1.0.0", packages=packages, long_description=readme, long_description_content_type='text/markdown', description="A TestLang compiler")