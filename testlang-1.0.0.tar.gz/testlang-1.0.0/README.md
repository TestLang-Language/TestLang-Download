# [Documentation Here](https://testlang-language.github.io/TestLang-site/testlang.html)
#[Links](https://testlang-language.github.io/TestLang-site/)
# [MIT License](https://github.com/TestLang-Language/TestLang-site/blob/main/LICENSE)